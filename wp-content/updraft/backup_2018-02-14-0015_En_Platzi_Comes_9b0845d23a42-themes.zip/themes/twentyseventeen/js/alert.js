jQuery(document).ready(function(){
  alert("Esto es un alert");
});
